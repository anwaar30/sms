<!-- Footer -->
<footer class="main">
	&copy; <?php echo date('Y')?> |School Management System|
    <strong>Anwaar</strong>
</footer>
